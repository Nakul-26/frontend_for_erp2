import React, { useState } from 'react';
import '../styles/Login.css';
import { FaUser, FaLock } from 'react-icons/fa';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      const response = await axios.post(
        'http://localhost:8000/admin/login',
        { id: userId, password },
        { withCredentials: true } // For JWT cookies
      );

      if (response.data.success) {
        console.log('Login successful');
        localStorage.setItem('adminData', JSON.stringify(response.data.data.admindata));
        navigate('/admin/dashboard');
      } else {
        setError('Invalid credentials');
      }
    } catch (error) {
      console.error('Error logging in:', error);
      setError(error.response?.data?.message || 'An error occurred during login');
    }
  };

  return (
    <div className="login-background">
      <div className="login-container">
        <div className="avatar">
          <FaUser size={40} color="#fff" />
        </div>
        <form className="login-form" onSubmit={handleSubmit}>
          <div className="input-group">
            <FaUser className="input-icon" />
            <input
              type="text"
              placeholder="Admin ID"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
            />
          </div>

          <div className="input-group">
            <FaLock className="input-icon" />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && (
            <div
              className="error-message"
              style={{ color: 'red', marginBottom: '10px', textAlign: 'center' }}
            >
              {error}
            </div>
          )}

          <div className="login-options">
            <a href="#">Forgot Password?</a>
          </div>

          <button type="submit" className="login-button">LOGIN</button>
        </form>
      </div>
    </div>
  );
}

export default Login;