import React from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../styles/Navbar.css';

function Navbar() {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      // Call backend logout endpoint (if exists) to clear tokens
      await axios.post(
        'http://localhost:8000/admin/logout',
        {},
        { withCredentials: true }
      );
      // Clear localStorage
      localStorage.removeItem('adminData');
      // Redirect to login page
      navigate('/login');
    } catch (error) {
      console.error('Error logging out:', error);
      // Clear localStorage and redirect even if backend call fails
      localStorage.removeItem('adminData');
      navigate('/login');
    }
  };

  return (
    <header className="dashboard-header">
      <h1>Admin Dashboard</h1>
      <div className="header-actions">
        <button className="profile-btn" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </header>
  );
}

export default Navbar;