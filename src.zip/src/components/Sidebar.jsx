import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Sidebar.css';

function Sidebar({ adminData }) {
  return (
    <aside className="sidebar">
      <div className="profile-section">
        <div className="profile-image">{adminData?.Name?.charAt(0) || 'A'}</div>
        <h3>{adminData?.Name || 'Loading...'}</h3>
        <p>{adminData?.email || 'Loading...'}</p>
      </div>
      <nav className="sidebar-nav">
        <Link to="/admin/dashboard" className="active">
          Dashboard
        </Link>
        <div className="nav-item">
          <Link to="/admin/classes">Classes</Link>
          <div className="submenu">
            <Link to="/admin/classes/add" className="submenu-item">
              Add Class
            </Link>
            <Link to="/admin/classes/remove" className="submenu-item">
              Remove Class
            </Link>
          </div>
        </div>
        <Link to="/admin/teachers">Manage Teachers</Link>
        <Link to="/admin/students">Manage Students</Link>
        <Link to="/admin/departments">Manage Departments</Link>
        <Link to="/admin/settings">Settings</Link>
      </nav>
    </aside>
  );
}

export default Sidebar;